export class User {
  name: string;
  password: string;
}

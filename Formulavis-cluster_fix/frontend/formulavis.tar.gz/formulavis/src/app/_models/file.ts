export class File {
  id: number;
  name: string;
  url: string;
  minimized: boolean;
}
